/*            *************************************************************
              *  Name of the challenge  :                                  *
              *                                                            *
              *  Developed for          : VHITECH Training Program         *
              *               Maintenance History                          *
              *  Developer              :                                  *
              *  Creation date           :                Ticket No:        *
              ************************************************************* */

// Declaration
// Screen date and time declaration.
let displayDate = new Date();
document.getElementById("dateOutput").innerHTML = displayDate.toLocaleDateString();
document.getElementById("timeOutput").innerHTML = displayDate.toLocaleTimeString();
//Input declaration
//Code Statements